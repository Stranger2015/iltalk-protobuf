# Contributions are welcome!

ProfaneDB is at a very early stage, so any contribution is of great help!  
Pull requests, bugs reports, enhancements and suggestions are very appreciated.

Being just a prototype tool I'm developing for some of my projects
I might overlook some features or deem them unimportant,
however do feel free to bring forward your use case,
and different choices might turn out to be better for ProfaneDB!


## Boy Scout Rule

Being a Scout myself I feel obliged to enforce the Boy Scout Rule,
and ask contributors to

> Leave this world a bit better than you found it.

Especially at this time of quick development and testing,
I'm already starting to work on this as I myself left the codebase very messy...


## Tests

I will setup tests and GitLab CI
(shame on me for not doing it at the very first stage)