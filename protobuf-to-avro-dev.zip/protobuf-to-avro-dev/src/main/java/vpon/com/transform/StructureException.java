package vpon.com.transform;

public class StructureException extends Exception {	
	public StructureException(String message) {
		super(message);
	}
}
