package vpon.com.transform;

public class UnSupportProtoFormatException extends Exception {	
	/**
	 * 
	 */
	private static final long serialVersionUID = 122L;

	public UnSupportProtoFormatException(String message) {
		super(message);
	}
}
