---
date : 2016-09-18T14:57:52+02:00
draft : false
title : Maven Dependency
---

protobuf-rpc-pro is available via the maven central repository http://repo1.maven.org/maven2. The demo examples are available under the artifactId "protocol-rpc-pro-demo".

```
		<dependency>
			<groupId>com.googlecode.protobuf-rpc-pro</groupId>
			<artifactId>protobuf-rpc-pro-duplex</artifactId>
			<version>3.3.4</version>
			<type>jar</type>
		</dependency>
```