protoc --java_out ../java protobuf-rpc-duplex.proto
protoc --java_out ../java protobuf-rpc-duplex-log.proto

