protoc --java_out ../java pingpong.proto


