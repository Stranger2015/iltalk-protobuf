package io.protostuff.generator.html.markdown;

public interface MarkdownProcessor {

    String toHtml(String source);
}
