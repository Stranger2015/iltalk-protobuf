# protostuff-rpc
dynamic protobuf-rpc without writing *.proto files
