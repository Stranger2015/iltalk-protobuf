# protogram
A static and dynamic protobuf library

Supports both annotated descriptions and dynamic properties through a json file

See example project for details
