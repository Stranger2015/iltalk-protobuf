﻿using System.Collections.Generic;

namespace ProtoGram.Protocol.Interfaces
{
    public interface IDynamicServiceDescription
    {
       
    }
}