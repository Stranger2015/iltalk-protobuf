﻿
using System.Runtime.Serialization;

namespace ProtoGram.Protocol.Interfaces
{
 
    public interface  IDynamicValue
    {
        object Value { get; set; }              
    }
}
