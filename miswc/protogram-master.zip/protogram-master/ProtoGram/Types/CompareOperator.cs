﻿namespace ProtoGram.Protocol.Types
{
    public enum CompareOperator
    {
        Equal
    }
}