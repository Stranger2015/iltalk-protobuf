﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProtoGram.Protocol
{
    public static class Const
    {
        public const int READTOEND = -1;
    }
}
