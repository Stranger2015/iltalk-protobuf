﻿using System;

namespace ProtoGram.Protocol.Encoding
{
    [AttributeUsage(AttributeTargets.Class)]
    sealed public class BinaryEncodingContractAttribute : Attribute
    {
    }
}