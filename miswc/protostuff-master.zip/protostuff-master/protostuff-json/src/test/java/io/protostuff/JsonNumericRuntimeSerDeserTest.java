//========================================================================
//Copyright 2007-2009 David Yu dyuproject@gmail.com
//------------------------------------------------------------------------
//Licensed under the Apache License, Version 2.0 (the "License");
//you may not use this file except in compliance with the License.
//You may obtain a copy of the License at 
//http://www.apache.org/licenses/LICENSE-2.0
//Unless required by applicable law or agreed to in writing, software
//distributed under the License is distributed on an "AS IS" BASIS,
//WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//See the License for the specific language governing permissions and
//limitations under the License.
//========================================================================

package io.protostuff;

import static io.protostuff.runtime.SerializableObjects.bar;
import static io.protostuff.runtime.SerializableObjects.baz;
import static io.protostuff.runtime.SerializableObjects.foo;
import static io.protostuff.runtime.SerializableObjects.negativeBar;
import static io.protostuff.runtime.SerializableObjects.negativeBaz;

import junit.framework.TestCase;
import io.protostuff.runtime.Bar;
import io.protostuff.runtime.Baz;
import io.protostuff.runtime.Foo;
import io.protostuff.runtime.PolymorphicSerializationTest;
import io.protostuff.runtime.PolymorphicSerializationTest.Zoo;
import io.protostuff.runtime.RuntimeSchema;
import io.protostuff.runtime.SerializableObjects;

/**
 * Testing for json ser/deser against runtime messages.
 * 
 * @author David Yu
 * @created Nov 20, 2009
 */
public class JsonNumericRuntimeSerDeserTest extends TestCase
{

    public void testFoo() throws Exception
    {
        Schema<Foo> schema = RuntimeSchema.getSchema(Foo.class);

        Foo fooCompare = foo;
        Foo dfoo = new Foo();

        byte[] data = JsonIOUtil.toByteArray(fooCompare, schema, true);
        JsonIOUtil.mergeFrom(data, dfoo, schema, true);
        SerializableObjects.assertEquals(fooCompare, dfoo);
    }

    public void testBar() throws Exception
    {
        Schema<Bar> schema = RuntimeSchema.getSchema(Bar.class);

        for (Bar barCompare : new Bar[] { bar, negativeBar })
        {
            Bar dbar = new Bar();

            byte[] data = JsonIOUtil.toByteArray(barCompare, schema, true);
            JsonIOUtil.mergeFrom(data, dbar, schema, true);
            SerializableObjects.assertEquals(barCompare, dbar);
        }
    }

    public void testBaz() throws Exception
    {
        Schema<Baz> schema = RuntimeSchema.getSchema(Baz.class);

        for (Baz bazCompare : new Baz[] { baz, negativeBaz })
        {
            Baz dbaz = new Baz();

            byte[] data = JsonIOUtil.toByteArray(bazCompare, schema, true);
            JsonIOUtil.mergeFrom(data, dbaz, schema, true);
            SerializableObjects.assertEquals(bazCompare, dbaz);
        }
    }

    public void testPolymorphic() throws Exception
    {
        Schema<Zoo> schema = RuntimeSchema.getSchema(Zoo.class);
        Zoo zooCompare = PolymorphicSerializationTest.filledZoo();

        Zoo dzoo = new Zoo();

        byte[] data = JsonIOUtil.toByteArray(zooCompare, schema, true);
        JsonIOUtil.mergeFrom(data, dzoo, schema, true);
        SerializableObjects.assertEquals(zooCompare, dzoo);
    }

}
