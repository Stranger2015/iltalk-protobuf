To generate a standalone jar:
$ mvn -Pjwd package

Then get the output jar at target/protostuff-compiler-$version-jarjar.jar
